package com.example.filemanager

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import java.util.zip.*

private val Blue = Color(0xFF3D8BFF)
private val Scheme = darkColorScheme(
    primary = Blue, onPrimary = Color.White,
    background = Color(0xFF0A0E16), surface = Color(0xFF0F1522),
    surfaceVariant = Color(0xFF1A2438), onSurface = Color(0xFFE6EBF5),
    onSurfaceVariant = Color(0xFF9FB0CC),
    secondaryContainer = Color(0xFF17315E), onSecondaryContainer = Color(0xFFD6E4FF)
)
private val CATS = mapOf(
    "Images" to setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "bmp"),
    "Vidéos" to setOf("mp4", "mkv", "webm", "3gp", "mov"),
    "Audio" to setOf("mp3", "m4a", "wav", "flac", "ogg", "aac"),
    "Documents" to setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt"),
    "APK" to setOf("apk")
)

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val t = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(SystemBarStyle.dark(t), SystemBarStyle.dark(t))
        setContent {
            MaterialTheme(colorScheme = Scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    if (granted) FileManager() else Permission()
                }
            }
        }
    }
    override fun onResume() { super.onResume(); granted = Environment.isExternalStorageManager() }

    @Composable
    fun Permission() = Column(
        Modifier.fillMaxSize().padding(32.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Icon(Icons.Default.FolderOpen, null, Modifier.size(72.dp), Blue)
        Spacer(Modifier.height(16.dp))
        Text("Accès à tous les fichiers requis", style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        }) { Text("Autoriser") }
    }
}

// ---------- Utilitaires ----------
private fun uniq(d: File, n: String): File {
    var t = File(d, n); var i = 1
    val base = File(n).nameWithoutExtension; val ext = File(n).extension.let { if (it.isEmpty()) "" else ".$it" }
    while (t.exists()) t = File(d, "$base (${i++})$ext")
    return t
}
private fun uri(c: Context, f: File) = FileProvider.getUriForFile(c, "${c.packageName}.fp", f)
private fun openFile(c: Context, f: File) {
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
    c.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(uri(c, f), mime)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
}
private fun share(c: Context, fs: List<File>) {
    if (fs.isEmpty()) return
    c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
        .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(fs.map { uri(c, it) }))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
}
private fun zip(files: List<File>, out: File) = ZipOutputStream(out.outputStream().buffered()).use { z ->
    files.forEach { f ->
        val base = f.parentFile!!
        (if (f.isDirectory) f.walkTopDown() else sequenceOf(f)).filter { it.isFile }.forEach {
            z.putNextEntry(ZipEntry(it.relativeTo(base).path)); it.inputStream().use { i -> i.copyTo(z) }; z.closeEntry()
        }
    }
}
private fun unzip(zf: File, dest: File) = ZipInputStream(zf.inputStream().buffered()).use { z ->
    dest.mkdirs()
    var e = z.nextEntry
    while (e != null) {
        val t = File(dest, e.name)
        if (t.canonicalPath.startsWith(dest.canonicalPath)) { // protection zip-slip
            if (e.isDirectory) t.mkdirs() else { t.parentFile?.mkdirs(); t.outputStream().use { z.copyTo(it) } }
        }
        e = z.nextEntry
    }
}
private fun iconFor(f: File): ImageVector = if (f.isDirectory) Icons.Default.Folder else when (f.extension.lowercase()) {
    in CATS["Images"]!! -> Icons.Default.Image
    in CATS["Vidéos"]!! -> Icons.Default.Movie
    in CATS["Audio"]!! -> Icons.Default.MusicNote
    in CATS["Documents"]!! -> Icons.Default.Description
    "zip", "rar", "7z", "tar", "gz" -> Icons.Default.FolderZip
    "apk" -> Icons.Default.Android
    else -> Icons.Default.InsertDriveFile
}
private fun catIcon(c: String) = when (c) {
    "Images" -> Icons.Default.Image; "Vidéos" -> Icons.Default.Movie
    "Audio" -> Icons.Default.MusicNote; "Documents" -> Icons.Default.Description; else -> Icons.Default.Android
}

// ---------- Écran principal ----------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileManager() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val root = remember { Environment.getExternalStorageDirectory() }
    val prefs = remember { ctx.getSharedPreferences("fm", 0) }
    var dir by remember { mutableStateOf(root) }
    var files by remember { mutableStateOf(emptyList<File>()) }
    var tick by remember { mutableIntStateOf(0) }
    var grid by remember { mutableStateOf(prefs.getBoolean("grid", false)) }
    var hidden by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf("Nom") }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var cat by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf(setOf<File>()) }
    var clip by remember { mutableStateOf<Pair<List<File>, Boolean>?>(null) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favs", emptySet())!!.toSet()) }
    var dlg by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var smenu by remember { mutableStateOf(false) }
    val cs = MaterialTheme.colorScheme

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun go(d: File) { dir = d; cat = null; query = ""; searching = false; sel = emptySet(); scope.launch { drawer.close() } }
    fun run(ok: String, block: () -> Unit) = scope.launch {
        try { withContext(Dispatchers.IO) { block() }; toast(ok) } catch (e: Exception) { toast(e.message ?: "Erreur") }
        sel = emptySet(); tick++
    }

    LaunchedEffect(dir, tick, hidden, sort, query, cat) {
        val c = cat; val q = query; val d = dir
        files = withContext(Dispatchers.IO) {
            val src = when {
                c != null -> root.walkTopDown().onEnter { it.name != "Android" && (hidden || !it.name.startsWith(".")) }
                    .filter { it.isFile && it.extension.lowercase() in CATS[c]!! }.take(2000)
                q.isNotBlank() -> d.walkTopDown().maxDepth(8).filter { it != d && it.name.contains(q, true) }.take(1000)
                else -> (d.listFiles() ?: emptyArray()).asSequence()
            }
            val cmp: Comparator<File> = when (sort) {
                "Taille" -> compareByDescending { it.length() }
                "Date" -> compareByDescending { it.lastModified() }
                "Type" -> compareBy { it.extension.lowercase() }
                else -> compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }
            }
            src.filter { hidden || !it.name.startsWith(".") }.toList()
                .sortedWith(compareByDescending<File> { it.isDirectory }.then(cmp))
        }
    }

    BackHandler(enabled = sel.isNotEmpty() || searching || cat != null || dir != root) {
        when {
            sel.isNotEmpty() -> sel = emptySet()
            searching || query.isNotEmpty() -> { searching = false; query = "" }
            cat != null -> cat = null
            else -> dir.parentFile?.let { dir = it }
        }
    }

    ModalNavigationDrawer(drawerState = drawer, drawerContent = {
        ModalDrawerSheet(drawerContainerColor = cs.surface) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp)) {
                val st = remember(tick) { StatFs(root.path) }
                val total = st.totalBytes; val used = total - st.availableBytes
                Column(Modifier.padding(12.dp)) {
                    Text("Stockage interne", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { (used.toFloat() / total).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = Blue, trackColor = cs.surfaceVariant)
                    Text("${Formatter.formatShortFileSize(ctx, used)} utilisés sur ${Formatter.formatShortFileSize(ctx, total)}",
                        style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                listOf("Accueil" to root, "Téléchargements" to File(root, "Download"), "Photos" to File(root, "DCIM"),
                    "Documents" to File(root, "Documents"), "Musique" to File(root, "Music")).forEach { (n, f) ->
                    NavigationDrawerItem(label = { Text(n) }, selected = cat == null && dir == f,
                        icon = { Icon(if (f == root) Icons.Default.Smartphone else Icons.Default.Folder, null) },
                        onClick = { go(f) })
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                CATS.keys.forEach { c ->
                    NavigationDrawerItem(label = { Text(c) }, selected = cat == c, icon = { Icon(catIcon(c), null) },
                        onClick = { go(root); cat = c })
                }
                if (favs.isNotEmpty()) {
                    HorizontalDivider(Modifier.padding(vertical = 8.dp))
                    favs.forEach { p ->
                        NavigationDrawerItem(label = { Text(File(p).name) }, selected = false,
                            icon = { Icon(Icons.Default.Star, null, tint = Blue) }, onClick = { go(File(p)) })
                    }
                }
            }
        }
    }) {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                val colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.surface)
                if (sel.isNotEmpty()) TopAppBar(colors = colors,
                    title = { Text("${sel.size} sélectionné(s)") },
                    navigationIcon = { IconButton({ sel = emptySet() }) { Icon(Icons.Default.Close, null) } },
                    actions = {
                        IconButton({ clip = sel.toList() to false; sel = emptySet() }) { Icon(Icons.Default.ContentCopy, "Copier") }
                        IconButton({ clip = sel.toList() to true; sel = emptySet() }) { Icon(Icons.Default.ContentCut, "Couper") }
                        IconButton({ dlg = "delete" }) { Icon(Icons.Default.Delete, "Supprimer") }
                        Box {
                            IconButton({ smenu = true }) { Icon(Icons.Default.MoreVert, null) }
                            DropdownMenu(smenu, { smenu = false }) {
                                DropdownMenuItem({ Text("Tout sélectionner") }, { sel = files.toSet(); smenu = false })
                                DropdownMenuItem({ Text("Partager") }, { share(ctx, sel.filter { it.isFile }); smenu = false })
                                DropdownMenuItem({ Text("Compresser (ZIP)") }, {
                                    smenu = false; val l = sel.toList(); val d = dir
                                    run("ZIP créé") { zip(l, uniq(d, "archive.zip")) }
                                })
                                if (sel.size == 1 && sel.first().extension.equals("zip", true))
                                    DropdownMenuItem({ Text("Extraire ici") }, {
                                        smenu = false; val f = sel.first(); val d = dir
                                        run("Extrait") { unzip(f, uniq(d, f.nameWithoutExtension)) }
                                    })
                                if (sel.size == 1) DropdownMenuItem({ Text("Renommer") }, { smenu = false; text = sel.first().name; dlg = "rename" })
                                DropdownMenuItem({ Text("Favori ★") }, {
                                    smenu = false
                                    val ds = sel.filter { it.isDirectory }.map { it.path }
                                    favs = if (favs.containsAll(ds)) favs - ds.toSet() else favs + ds
                                    prefs.edit().putStringSet("favs", favs).apply(); sel = emptySet()
                                })
                                DropdownMenuItem({ Text("Informations") }, { smenu = false; dlg = "info" })
                            }
                        }
                    })
                else TopAppBar(colors = colors,
                    title = {
                        if (searching) TextField(query, { query = it }, singleLine = true, placeholder = { Text("Rechercher…") },
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                        else Text(cat ?: dir.name.ifEmpty { "Stockage" }, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    },
                    navigationIcon = { IconButton({ scope.launch { drawer.open() } }) { Icon(Icons.Default.Menu, null) } },
                    actions = {
                        IconButton({ searching = !searching; if (!searching) query = "" }) { Icon(Icons.Default.Search, "Rechercher") }
                        IconButton({ grid = !grid; prefs.edit().putBoolean("grid", grid).apply() }) {
                            Icon(if (grid) Icons.Default.ViewList else Icons.Default.GridView, "Affichage")
                        }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null) }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem({ Text("Nouveau dossier") }, { menu = false; text = ""; dlg = "folder" })
                                DropdownMenuItem({ Text("Nouveau fichier") }, { menu = false; text = ""; dlg = "file" })
                                HorizontalDivider()
                                listOf("Nom", "Date", "Taille", "Type").forEach {
                                    DropdownMenuItem({ Text("Trier : " + if (it == sort) "✓ $it" else it) }, { sort = it; menu = false })
                                }
                                HorizontalDivider()
                                DropdownMenuItem({ Text("Fichiers cachés : " + if (hidden) "oui" else "non") }, { hidden = !hidden; menu = false })
                                DropdownMenuItem({ Text("Actualiser") }, { tick++; menu = false })
                            }
                        }
                    })
            },
            bottomBar = {
                clip?.let { (list, cut) ->
                    BottomAppBar(containerColor = cs.surfaceVariant) {
                        Text("${list.size} élément(s) · " + if (cut) "Déplacer" else "Copier",
                            Modifier.padding(start = 16.dp).weight(1f))
                        TextButton({ clip = null }) { Text("Annuler") }
                        Button({
                            val d = dir; clip = null
                            run("Terminé") {
                                list.forEach { f ->
                                    check(!(f.isDirectory && d.canonicalPath.startsWith(f.canonicalPath))) { "Destination invalide" }
                                    val t = uniq(d, f.name)
                                    if (cut) { if (!f.renameTo(t)) { f.copyRecursively(t); f.deleteRecursively() } }
                                    else f.copyRecursively(t)
                                }
                            }
                        }, Modifier.padding(horizontal = 8.dp)) { Text("Coller") }
                    }
                }
            }
        ) { pad ->
            Column(Modifier.padding(pad)) {
                if (cat == null && query.isBlank()) {
                    val crumbs = generateSequence(dir) { if (it == root) null else it.parentFile }.toList().reversed()
                    LazyRow(contentPadding = PaddingValues(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        items(crumbs) { c ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (c == root) "Stockage" else c.name,
                                    color = if (c == dir) Blue else cs.onSurfaceVariant,
                                    modifier = Modifier.clickable { go(c) }.padding(8.dp))
                                Icon(Icons.Default.ChevronRight, null, tint = cs.onSurfaceVariant)
                            }
                        }
                    }
                }
                val tap = { f: File ->
                    when {
                        sel.isNotEmpty() -> sel = if (f in sel) sel - f else sel + f
                        f.isDirectory -> go(f)
                        else -> try { openFile(ctx, f) } catch (e: Exception) { toast("Aucune appli pour ouvrir ce fichier") }
                    }
                }
                val long = { f: File -> sel = if (f in sel) sel - f else sel + f }
                if (files.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Aucun élément", color = cs.onSurfaceVariant) }
                else if (grid) LazyVerticalGrid(GridCells.Adaptive(100.dp), contentPadding = PaddingValues(8.dp)) {
                    items(files, key = { it.path }) { f -> Entry(f, true, f in sel, { tap(f) }, { long(f) }) }
                } else LazyColumn(contentPadding = PaddingValues(8.dp)) {
                    items(files, key = { it.path }) { f -> Entry(f, false, f in sel, { tap(f) }, { long(f) }) }
                }
            }
        }
    }

    // ---------- Boîtes de dialogue ----------
    if (dlg in setOf("folder", "file", "rename")) AlertDialog(
        onDismissRequest = { dlg = "" },
        title = { Text(when (dlg) { "folder" -> "Nouveau dossier"; "file" -> "Nouveau fichier"; else -> "Renommer" }) },
        text = { OutlinedTextField(text, { text = it }, singleLine = true) },
        confirmButton = {
            TextButton({
                val k = dlg; val n = text.trim(); val t = sel.firstOrNull(); val d = dir; dlg = ""
                if (n.isNotEmpty()) run("OK") {
                    when (k) {
                        "folder" -> check(File(d, n).mkdirs()) { "Échec de création" }
                        "file" -> check(File(d, n).createNewFile()) { "Échec de création" }
                        else -> check(t!!.renameTo(File(t.parentFile, n))) { "Échec du renommage" }
                    }
                }
            }) { Text("OK") }
        },
        dismissButton = { TextButton({ dlg = "" }) { Text("Annuler") } })

    if (dlg == "delete") AlertDialog(
        onDismissRequest = { dlg = "" },
        title = { Text("Supprimer ${sel.size} élément(s) ?") },
        text = { Text("Cette action est définitive.") },
        confirmButton = {
            TextButton({ val l = sel.toList(); dlg = ""; run("Supprimé") { l.forEach { it.deleteRecursively() } } }) { Text("Supprimer") }
        },
        dismissButton = { TextButton({ dlg = "" }) { Text("Annuler") } })

    if (dlg == "info") {
        val items = sel.ifEmpty { setOf(dir) }
        val size by produceState(0L, items) {
            value = withContext(Dispatchers.IO) { items.sumOf { i -> i.walkTopDown().filter { it.isFile }.sumOf { it.length() } } }
        }
        AlertDialog(onDismissRequest = { dlg = "" }, title = { Text("Informations") },
            text = {
                Column {
                    val f = items.first()
                    Text(if (items.size > 1) "${items.size} éléments" else f.name, style = MaterialTheme.typography.titleSmall)
                    Text("Taille : ${Formatter.formatShortFileSize(ctx, size)}")
                    if (items.size == 1) {
                        Text("Chemin : ${f.parent}")
                        Text("Modifié : ${DateFormat.getDateTimeInstance().format(Date(f.lastModified()))}")
                        Text("Type : " + if (f.isDirectory) "Dossier" else f.extension.ifEmpty { "Fichier" })
                    }
                }
            },
            confirmButton = { TextButton({ dlg = "" }) { Text("Fermer") } })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Entry(f: File, grid: Boolean, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val tint = if (f.isDirectory) Blue else cs.onSurfaceVariant
    val mod = Modifier.clip(RoundedCornerShape(14.dp))
        .background(if (selected) cs.secondaryContainer else Color.Transparent)
        .combinedClickable(onClick = onClick, onLongClick = onLong)
    if (grid) Column(mod.fillMaxWidth().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(iconFor(f), null, Modifier.size(44.dp), tint)
        Text(f.name, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            style = MaterialTheme.typography.labelMedium)
    } else Row(mod.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(iconFor(f), null, Modifier.size(36.dp), tint)
        Column(Modifier.padding(start = 14.dp).weight(1f)) {
            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val info = if (f.isDirectory) "${f.list()?.size ?: 0} élément(s)" else Formatter.formatShortFileSize(ctx, f.length())
            Text("$info · ${DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(f.lastModified()))}",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        if (selected) Icon(Icons.Default.CheckCircle, null, tint = Blue)
    }
}
